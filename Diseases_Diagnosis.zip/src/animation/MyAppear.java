package animation;


import javafx.animation.FadeTransition;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class MyAppear {

	public static void startAnimation(Node node, double start, double end, int delay) {
		FadeTransition fadeTransition = new FadeTransition(Duration.millis(500), node);
		fadeTransition.setDelay(Duration.millis(delay));
		fadeTransition.setFromValue(start);
		fadeTransition.setToValue(end);
		fadeTransition.setAutoReverse(true);
		fadeTransition.playFromStart();
	}
	
	public static void startAnimation(AnchorPane node, double start, double end, int delay) {
		FadeTransition fadeTransition = new FadeTransition(Duration.millis(500), node);
		fadeTransition.setDelay(Duration.millis(delay));
		fadeTransition.setFromValue(start);
		fadeTransition.setToValue(end);
		fadeTransition.setAutoReverse(true);
		fadeTransition.playFromStart();
	}
}

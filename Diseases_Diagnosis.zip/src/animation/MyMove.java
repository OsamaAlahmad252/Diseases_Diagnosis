package animation;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class MyMove {
	public static void startMove(Node node, double x, double y, int duration, int delay) {
		TranslateTransition translateTransition = new TranslateTransition(Duration.millis(duration), node);
		translateTransition.setDelay(Duration.millis(delay));
		translateTransition.setToX(x);
		translateTransition.setToY(y);
		translateTransition.setAutoReverse(false);
		translateTransition.play();
	}

	public static void startMove(AnchorPane pane, double x, double y, int duration, int delay) {
		TranslateTransition translateTransition = new TranslateTransition(Duration.millis(duration), pane);
		translateTransition.setDelay(Duration.millis(delay));
		translateTransition.setToX(x);
		translateTransition.setToY(y);
		translateTransition.setAutoReverse(false);
		translateTransition.play();
	}

}

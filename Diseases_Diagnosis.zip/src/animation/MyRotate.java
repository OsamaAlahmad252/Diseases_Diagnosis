package animation;

import javafx.animation.RotateTransition;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class MyRotate {
	public static void start(Node node, double degree, int duration, int delay) {
		RotateTransition rotateTransition = new	RotateTransition(Duration.millis(duration), node);
		rotateTransition.setDelay(Duration.millis(delay));
		rotateTransition.setToAngle(degree);
		rotateTransition.setAutoReverse(false);
		rotateTransition.play();
	}

	public static void start(AnchorPane pane, double degree, int duration,int delay) {
		RotateTransition rotateTransition = new	RotateTransition(Duration.millis(duration), pane);
		rotateTransition.setDelay(Duration.millis(delay));
		rotateTransition.setToAngle(degree);
		rotateTransition.setAutoReverse(false);
		rotateTransition.play();
	}
}

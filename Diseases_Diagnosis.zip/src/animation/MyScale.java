package animation;

import javafx.animation.ScaleTransition;
import javafx.scene.Node;
import javafx.scene.layout.AnchorPane;
import javafx.util.Duration;

public class MyScale {
	public static void startScale(Node node, double x, double y,int delay) {
		ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(500), node);				
		scaleTransition.setDelay(Duration.millis(delay));
		scaleTransition.setToX(x);
		scaleTransition.setToY(y);
		scaleTransition.setAutoReverse(false);	
		scaleTransition.playFromStart();
	}
	
	public static void startScale(AnchorPane pane, double x, double y, int delay) {
		ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(500), pane);
		scaleTransition.setDelay(Duration.millis(delay));
		scaleTransition.setToX(x);
		scaleTransition.setToY(y);
		scaleTransition.setAutoReverse(false);	
		scaleTransition.playFromStart();
	}
	
	public static void startScale(Node node, double x, double y, int duration,int delay) {
		ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(duration), node);				
		scaleTransition.setDelay(Duration.millis(delay));
		scaleTransition.setToX(x);
		scaleTransition.setToY(y);
		scaleTransition.setAutoReverse(false);	
		scaleTransition.playFromStart();
	}
	
	public static void startScale(AnchorPane pane, double x, double y,int duration, int delay) {
		ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(duration), pane);
		scaleTransition.setDelay(Duration.millis(delay));
		scaleTransition.setToX(x);
		scaleTransition.setToY(y);
		scaleTransition.setAutoReverse(false);	
		scaleTransition.playFromStart();
	}

}

package controller;

import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.Map;
import java.util.ResourceBundle;

import org.jpl7.Query;
import org.jpl7.Term;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXListView;

import animation.MyMove;
import animation.MyRotate;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class DiseasesController implements Initializable {

	// AnchorPanes
	@FXML
	private AnchorPane possibleDiseasesPane;
	@FXML
	private AnchorPane diseaseSymptomsPane;
	@FXML
	private AnchorPane diseaseDrugsPane;
	@FXML
	private AnchorPane resultPossiblePane;
	@FXML
	private AnchorPane optionBtn;
	// ListViews
	@FXML
	private JFXListView<String> listViewOne;
	@FXML
	private JFXListView<String> listViewTwo;
	@FXML
	private JFXListView<String> listViewThree;
	@FXML
	private JFXListView<String> listViewFour;
	@FXML
	private JFXListView<String> listViewFive;
	// ComboBoxs
	@FXML
	private JFXComboBox<String> symptomCombo;
	@FXML
	private JFXComboBox<String> diseaseCombo;
	// Labels
	@FXML
	private Label adviceLabel;
	// ---------------------- Common Elements------------------------
	@FXML
	private AnchorPane optionPane;
	@FXML
	private JFXButton diseasesInfo;
	@FXML
	private JFXButton homeBtn;
	@FXML
	private JFXButton aboutUsBtn;
	@FXML
	private JFXButton exitBtn;


	
	private LinkedList<String> diseasesList = new LinkedList<>();
	private LinkedList<String> selectedSymptoms = new LinkedList<>();
	private boolean isOpen = false;
	
	
	// ======================== Methods ===========================
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		startForm();
		
		Query query = new Query("consult('prolog.pro')");
		query.hasSolution();
		
		
		// Initialize Symptom ComboBox
		query = new Query("getAllSymptoms(Symptoms).");
		Map<String, Term>[] result = query.allSolutions();
		LinkedList<String> symptoms= splitSymptoms(result[0].get("Symptoms").toString().trim());
		symptomCombo.getItems().addAll(symptoms);
		
		
		// Initialize Disease ComboBox
		query = new Query("getAllDiseases(Diseases).");
		result = query.allSolutions();
		LinkedList<String> diseases = splitSymptoms(result[0].get("Diseases").toString().trim());
		diseaseCombo.getItems().addAll(diseases);
		
		
			
		
		diseasesInfo.setAlignment(Pos.CENTER_LEFT);
		homeBtn.setAlignment(Pos.CENTER_LEFT);
		aboutUsBtn.setAlignment(Pos.CENTER_LEFT);
		exitBtn.setAlignment(Pos.CENTER_LEFT);
	}

	public void sendSymptom(ActionEvent event) {
		if(symptomCombo.getValue() != null) {
			listViewOne.getItems().clear();
			listViewTwo.getItems().clear();
			listViewThree.getItems().clear();
			
			selectedSymptoms.add(symptomCombo.getValue().trim());
			
			Query query = new Query("consult('prolog.pro')");
			query.hasSolution();		
			query = new Query("getSameDiseasesSymptom(" + symptomCombo.getValue().trim() + ", Diseases).");
			Map<String, Term>[] result = query.allSolutions();
			LinkedList<String> sameDiseasesSymptom = splitSymptoms(result[0].get("Diseases").toString().trim());
			
			for(int i = 0; i < sameDiseasesSymptom.size(); i++) {
				if(!isMember(diseasesList, sameDiseasesSymptom.get(i))) {
					diseasesList.add(sameDiseasesSymptom.get(i));
				}
			}
			
			selectedSymptoms = deleteRepeated(selectedSymptoms);
			
			listViewOne.getItems().addAll(sameDiseasesSymptom);
			listViewTwo.getItems().addAll(diseasesList);
			listViewThree.getItems().addAll(selectedSymptoms);
		}
		
	}

	public void clearDiseases(ActionEvent event) {
		listViewOne.getItems().clear();
		listViewTwo.getItems().clear();
		listViewThree.getItems().clear();
		diseasesList.clear();
		selectedSymptoms.clear();
	}

	public void sendDisease(ActionEvent event) {
		if(diseaseCombo.getValue() != null) {
			listViewFour.getItems().clear();
			listViewFive.getItems().clear();
			adviceLabel.setText("");
			
			Query query = new Query("consult('prolog.pro')");
			query.hasSolution();		
			
			// Get All Disease Symptoms
			query = new Query("getAllDiseaseSymptoms(" + diseaseCombo.getValue().trim() + ", Symptoms).");
			Map<String, Term>[] result = query.allSolutions();
			LinkedList<String> diseaseSymptoms = splitSymptoms(result[0].get("Symptoms").toString().trim());
			
			// Get All Disease Drugs
			query = new Query("drug(" + diseaseCombo.getValue().trim() + ", Drugs).");
			result = query.allSolutions();
			LinkedList<String> diseaseDrugs = splitDrugs(result[0].get("Drugs").toString().trim());
			
			// Get Disease Advice
			query = new Query("advice(" + diseaseCombo.getValue().trim() + ", Advice).");
			result = query.allSolutions();
			String Advice = getString(result[0].get("Advice").toString().trim());
			
			listViewFour.getItems().addAll(diseaseSymptoms);
			listViewFive.getItems().addAll(diseaseDrugs);
			adviceLabel.setText(Advice);
		}
	}
	
	public void startForm() {
		MyMove.startMove(possibleDiseasesPane, 80+392, 0, 500, 0);
		MyMove.startMove(diseaseSymptomsPane, 530-1000, 0, 500, 250);
		MyMove.startMove(diseaseDrugsPane, 530-1000, 0, 500, 500);
	}
	

	// --------------------------- Common Methods -----------------------------------
	public void options(MouseEvent event) {
		if (isOpen) {
			MyMove.startMove(optionPane, 0, 0, 250, 0);
			MyRotate.start(optionBtn, 0, 500, 0);
			isOpen = false;
		} else {
			MyMove.startMove(optionPane, 0, 160, 250, 0);
			MyRotate.start(optionBtn, 180, 500, 0);
			isOpen = true;
		}
	}

	public void diseasesInfo(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/DiseasesInfoScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void home(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void aboutUs(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AboutUsScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void exit(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.close();
	}
	
	
	
	
	
	private LinkedList<String> splitSymptoms(String str) {
		LinkedList<String> splitResult = new LinkedList<>();
		String[] strTempArr = {};
		char[] charArray = str.toCharArray();
		String strTemp = "";
		
		// Delete left and right square brackets.
		for (int i = 1; i < charArray.length - 1; i++) {
			strTemp += charArray[i];
		}
		strTempArr = strTemp.split(",");

		// Delete spaces from first and last each element.
		for(int i = 0; i < strTempArr.length; i++) {
			splitResult.add(strTempArr[i].trim());
		}
		
		return deleteRepeated(splitResult);
	}
	
	private LinkedList<String> splitDrugs(String str) {
		LinkedList<String> splitResult = new LinkedList<>();
		String[] strTempArr = {};
		char[] charArray = str.toCharArray();
		String strTemp = "";
		
		// Delete left and right square brackets.
		for (int i = 1; i < charArray.length - 1; i++) {
			strTemp += charArray[i];
		}
		strTempArr = strTemp.split(",");

		// Delete spaces from first and last each element.
		for(int i = 0; i < strTempArr.length; i++) {
			splitResult.add(getString(strTempArr[i].trim()));
		}
		
		return deleteRepeated(splitResult);
	}

	private LinkedList<String> deleteRepeated(LinkedList<String>  strArr) {
		LinkedList<String> deleteRepeated = new LinkedList<>();
		
		// Delete the repeated elements.
		for (int i = 0; i < strArr.size(); i++) {
			if(!isMember(deleteRepeated, strArr.get(i))) {
				deleteRepeated.add(strArr.get(i));
			}
		}
		
		return deleteRepeated;
	}
	
	private boolean isMember(LinkedList<String> strArr, String str) {
		// Check if the element is a member in the array.
		for (int i = 0; i < strArr.size(); i++) {
			if (strArr.get(i).equalsIgnoreCase(str)) {
				return true;
			}
		}
		return false;
	}
	
	private String getString(String str) {
		String getString = "";
		char[] temp = str.toCharArray();
		
		
		for(int i = 1; i < str.length() -1; i++) {
			getString += temp[i];
		}
		
		return getString;
	}

	
	
	
}

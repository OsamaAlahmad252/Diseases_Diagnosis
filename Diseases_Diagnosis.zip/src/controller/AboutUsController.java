package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXButton;

import animation.MyMove;
import animation.MyRotate;
import animation.MyScale;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class AboutUsController implements Initializable {

	// ImageVeiws
	@FXML
	private ImageView whatsappRoyLink;
	@FXML
	private ImageView instagramRoyLink;
	@FXML
	private ImageView telegramRoyLink;
	@FXML
	private ImageView whatsappOsamaLink;
	@FXML
	private ImageView instagramOsamaLink;
	@FXML
	private ImageView telegramOsamaLink;

	// Rectangle
	@FXML
	private Rectangle roy_whatsRectangle;
	@FXML
	private Rectangle roy_instaRectangle;
	@FXML
	private Rectangle roy_teleRectangle;
	@FXML
	private Rectangle osa_whatsRectangle;
	@FXML
	private Rectangle osa_instaRectangle;
	@FXML
	private Rectangle osa_teleRectangle;
	
	// Circles
	@FXML
	private Circle royanImage;
	@FXML
	private Circle osamaImage;
	
	// AnchorPanes
	@FXML
	private AnchorPane royanPane;
	@FXML
	private AnchorPane roy_whatsPane;
	@FXML
	private AnchorPane roy_instaPane;
	@FXML
	private AnchorPane roy_telePane;
	@FXML
	private AnchorPane osamaPane;
	@FXML
	private AnchorPane osa_whatsPane;
	@FXML
	private AnchorPane osa_instaPane;
	@FXML
	private AnchorPane osa_telePane;
	
	// ---------------------- Common Elements------------------------
	@FXML
	private AnchorPane optionBtn;
	@FXML
	private AnchorPane optionPane;
	@FXML
	private JFXButton diseasesInfo;
	@FXML
	private JFXButton homeBtn;
	@FXML
	private JFXButton aboutUsBtn;
	@FXML
	private JFXButton exitBtn;

	private boolean isOpen = false;
	// Roy
	private boolean roy_whatsapp_isOpen = false;
	private boolean roy_istagram_isOpen = false;
	private boolean roy_telegram_isOpen = false;
	// Osa
	private boolean osa_whatsapp_isOpen = false;
	private boolean osa_istagram_isOpen = false;
	private boolean osa_telegram_isOpen = false;

	// ======================== Methods ===========================
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		startForm();

		diseasesInfo.setAlignment(Pos.CENTER_LEFT);
		homeBtn.setAlignment(Pos.CENTER_LEFT);
		aboutUsBtn.setAlignment(Pos.CENTER_LEFT);
		exitBtn.setAlignment(Pos.CENTER_LEFT);

		try {
			Image im = new Image("/assets/Osama.jpg");
			osamaImage.setFill(new ImagePattern(im));
			im = new Image("/assets/Roy.jpg");
			royanImage.setFill(new ImagePattern(im));
			
//			im = new Image("/assets/...");
//			roy_whatsRectangle.setFill(new ImagePattern(im));
//			im = new Image("/assets/...");
//			roy_instaRectangle.setFill(new ImagePattern(im));
//			im = new Image("/assets/...");
//			roy_teleRectangle.setFill(new ImagePattern(im));
			
			im = new Image("/assets/osa_whatsap.png");
			osa_whatsRectangle.setFill(new ImagePattern(im));
			im = new Image("/assets/osa_insta.png");
			osa_instaRectangle.setFill(new ImagePattern(im));
			im = new Image("/assets/osa_tele.jpg");
			osa_teleRectangle.setFill(new ImagePattern(im));
			
		} catch (Exception e) {}
		
		MyScale.startScale(roy_whatsPane, 0, 0, 250, 0);
		MyScale.startScale(roy_instaPane, 0, 0, 250, 0);
		MyScale.startScale(roy_telePane, 0, 0, 250, 0);
		
		MyScale.startScale(osa_whatsPane, 0, 0, 250, 0);
		MyScale.startScale(osa_instaPane, 0, 0, 250, 0);
		MyScale.startScale(osa_telePane, 0, 0, 250, 0);
		
		
	}

	public void startForm() {
		MyMove.startMove(osamaPane, 125 + 350, 0, 500, 250);
		MyMove.startMove(royanPane, 525 - 1000, 0, 500, 0);

	}

	public void facebookOsamaOpenLink(MouseEvent event) {

	}

	// ---------- Animations ---------
	// Roy
	public void pressed_facebookRoyLink(MouseEvent event) {
		MyScale.startScale(whatsappRoyLink, 0.7, 0.7, 50, 0);
	}

	public void released_facebookRoyLink(MouseEvent event) {
		MyScale.startScale(whatsappRoyLink, 1, 1, 250, 0);
		if(!roy_whatsapp_isOpen) {
			MyScale.startScale(roy_whatsPane, 1, 1, 250, 0);
			roy_whatsapp_isOpen = true;
		} else {
			MyScale.startScale(roy_whatsPane, 0, 0, 250, 0);
			roy_whatsapp_isOpen = false;
		}
	}

	public void pressed_instagramRoyLink(MouseEvent event) {
		MyScale.startScale(instagramRoyLink, 0.7, 0.7, 50, 0);
	}

	public void released_instagramRoyLink(MouseEvent event) {
		MyScale.startScale(instagramRoyLink, 1, 1, 250, 0);
		if(!roy_istagram_isOpen) {
			MyScale.startScale(roy_instaPane, 1, 1, 250, 0);
			roy_istagram_isOpen = true;
		} else {
			MyScale.startScale(roy_instaPane, 0, 0, 250, 0);
			roy_istagram_isOpen = false;
		}
	}

	public void pressed_telegramRoyLink(MouseEvent event) {
		MyScale.startScale(telegramRoyLink, 0.7, 0.7, 50, 0);
	}

	public void released_telegramRoyLink(MouseEvent event) {
		MyScale.startScale(telegramRoyLink, 1, 1, 250, 0);
		if(!roy_telegram_isOpen) {
			MyScale.startScale(roy_telePane, 1, 1, 250, 0);
			roy_telegram_isOpen = true;
		} else {
			MyScale.startScale(roy_telePane, 0, 0, 250, 0);
			roy_telegram_isOpen = false;
		}
	}

	
	// Osa
	public void pressed_facebookOsamaLink(MouseEvent event) {
		MyScale.startScale(whatsappOsamaLink, 0.7, 0.7, 50, 0);
	}

	public void released_facebookOsamaLink(MouseEvent event) {
		MyScale.startScale(whatsappOsamaLink, 1, 1, 250, 0);
		if(!osa_whatsapp_isOpen) {
			MyScale.startScale(osa_whatsPane, 1, 1, 250, 0);
			osa_whatsapp_isOpen = true;
		} else {
			MyScale.startScale(osa_whatsPane, 0, 0, 250, 0);
			osa_whatsapp_isOpen = false;
		}
	}

	public void pressed_instagramOsamaLink(MouseEvent event) {
		MyScale.startScale(instagramOsamaLink, 0.7, 0.7, 50, 0);
	}

	public void released_instagramOsamaLink(MouseEvent event) {
		MyScale.startScale(instagramOsamaLink, 1, 1, 250, 0);
		if(!osa_istagram_isOpen) {
			MyScale.startScale(osa_instaPane, 1, 1, 250, 0);
			osa_istagram_isOpen = true;
		} else {
			MyScale.startScale(osa_instaPane, 0, 0, 250, 0);
			osa_istagram_isOpen = false;
		}
	}

	public void pressed_telegramOsamaLink(MouseEvent event) {
		MyScale.startScale(telegramOsamaLink, 0.7, 0.7, 50, 0);
	}

	public void released_telegramOsamaLink(MouseEvent event) {
		MyScale.startScale(telegramOsamaLink, 1, 1, 250, 0);
		if(!osa_telegram_isOpen) {
			MyScale.startScale(osa_telePane, 1, 1, 250, 0);
			osa_telegram_isOpen = true;
		} else {
			MyScale.startScale(osa_telePane, 0, 0, 250, 0);
			osa_telegram_isOpen = false;
		}
	}

	
	
	
	// --------------------------- Common Methods -----------------------------------

	public void options(MouseEvent event) {
		if (isOpen) {
			MyMove.startMove(optionPane, 0, 0, 250, 0);
			MyRotate.start(optionBtn, 0, 500, 0);
			isOpen = false;
		} else {
			MyMove.startMove(optionPane, 0, 160, 250, 0);
			MyRotate.start(optionBtn, 180, 500, 0);
			isOpen = true;
		}
	}

	public void diseasesInfo(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/DiseasesInfoScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void home(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void aboutUs(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AboutUsScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void exit(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.close();
	}

}

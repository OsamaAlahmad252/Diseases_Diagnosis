package controller;

import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.Map;
import java.util.ResourceBundle;

import org.jpl7.Query;
import org.jpl7.Term;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXListView;

import animation.MyAppear;
import animation.MyMove;
import animation.MyRotate;
import animation.MyScale;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainController implements Initializable {
	
	// Labels
	@FXML
	private Label patientLabel;
	@FXML
	private Label patientLabel2;
	@FXML
	private Label patientLabel3;
	@FXML
	private Label doctorLabel;
	@FXML
	private Label doctorLabel2;
	@FXML
	private Label resultDiagnosis;
	// ComboBoxs
	@FXML
	private JFXComboBox<String> symptomsCombo;
	// ListViews
	@FXML
	private JFXListView<String> listView;
	// AnchorPanes
	@FXML
	private AnchorPane patientPane;
	@FXML
	private AnchorPane startPane;
	@FXML
	private AnchorPane resultPane;
	@FXML
	private AnchorPane optionBtn;
	// ImageViews
	@FXML
	private ImageView patient;
	@FXML
	private ImageView doctor;
	
	
	// ---------------------- Common Elements------------------------
	@FXML
	private AnchorPane optionPane;
	@FXML
	private JFXButton diseasesInfo;
	@FXML
	private JFXButton homeBtn;
	@FXML
	private JFXButton aboutUsBtn;
	@FXML
	private JFXButton exitBtn;

	private LinkedList<String> selectedSymptom = new LinkedList<>();
	private boolean isOpen = false;

	
	
	// ======================== Methods ===========================
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Query query = new Query("consult('prolog.pro')");
		query.hasSolution();
		query = new Query("getAllSymptoms(Symptoms).");
		Map<String, Term>[] result = query.allSolutions();
		LinkedList<String> symptoms = splitSymptoms(result[0].get("Symptoms").toString().trim());
		symptomsCombo.getItems().addAll(symptoms);

		diseasesInfo.setAlignment(Pos.CENTER_LEFT);
		homeBtn.setAlignment(Pos.CENTER_LEFT);
		aboutUsBtn.setAlignment(Pos.CENTER_LEFT);
		exitBtn.setAlignment(Pos.CENTER_LEFT);
	}

	public void sendSymptoms(ActionEvent event) {
		
		Query query = new Query("consult('prolog.pro')");
		query.hasSolution();
		
		query = new Query("startDiagnosis(Disease, Drugs, Advice, " + convertListToString() + ").");
		Map<String, Term>[] result = query.allSolutions();

		if (result.length == 0) {
			doctorLabel.setText("Sorry, I can not diagsis these symptoms!");
			resultDiagnosis.setText("  You can browse DISEASES INFO to see\n  what disease you might have.");
			patientLabel3.setText("Ok doctor, Thank you very much.");
			MyAppear.startAnimation(doctorLabel, 0, 1, 0);
			MyMove.startMove(resultPane, -400, 0, 500, 500);
			MyAppear.startAnimation(patientLabel3, 0, 1, 1500);
		} else {
			String disease = result[0].get("Disease").toString().trim();
			String advice = getString(result[0].get("Advice").toString().trim());
			LinkedList<String> drugs = splitDrugs(result[0].get("Drugs").toString());

			doctorLabel.setText("Alright, Your Disease is: " + disease + ". Take Care..");
			resultDiagnosis.setText("  I suggest the following Drugs for you: \n\n");
			for (int i = 0; i < drugs.size(); i++) {
				resultDiagnosis.setText(resultDiagnosis.getText() + "  " + (i + 1) + "- " + drugs.get(i) + "\n");
			}
			resultDiagnosis.setText(resultDiagnosis.getText() + "\n  And my advice for you is:\n");
			resultDiagnosis.setText(resultDiagnosis.getText() + "  " + advice + ".");
			patientLabel3.setText("Ok doctor, Thank you very much.");

			MyAppear.startAnimation(doctorLabel, 0, 1, 0);
			MyMove.startMove(resultPane, -400, 0, 500, 500);
			MyAppear.startAnimation(patientLabel3, 0, 1, 1500);
		}
		
		patientPane.setDisable(true);
	}

	public void startDiagnosis(ActionEvent event) {
		startPane.setVisible(false);

		MyScale.startScale(doctor, 0.5, 0.5, 300);
		MyMove.startMove(doctor, 290, -110, 500, 300);
		MyMove.startMove(patient, 313, 0, 500, 800);

		MyAppear.startAnimation(patientLabel, 0, 1, 1500);
		MyAppear.startAnimation(doctorLabel, 0, 1, 2500);
		MyAppear.startAnimation(patientLabel, 1, 0, 4000);
		MyAppear.startAnimation(doctorLabel, 1, 0, 4000);
		MyAppear.startAnimation(patientLabel2, 0, 1, 5500);
		MyAppear.startAnimation(doctorLabel2, 0, 1, 6500);
		MyAppear.startAnimation(patientLabel2, 1, 0,8000);
		MyAppear.startAnimation(doctorLabel2, 1, 0, 8000);
		MyAppear.startAnimation(patientLabel3, 0, 1, 9500);

		MyMove.startMove(patientPane, 365 + 56, 0, 500, 9500);

		MyAppear.startAnimation(patientLabel3, 1, 0, 11000);
	}

	public void choiceSymptom(ActionEvent event) {
		selectedSymptom.add(symptomsCombo.getValue());
		listView.getItems().add(symptomsCombo.getValue());
	}

	public void restartDiagnosis(ActionEvent event) {
		patientPane.setDisable(false);
		selectedSymptom.clear();
		listView.getItems().clear();
		MyAppear.startAnimation(doctorLabel, 1, 0, 0);
		MyMove.startMove(resultPane, +400, 0, 500, 0);
		MyAppear.startAnimation(patientLabel3, 1, 0, 0);
		
	}
	
	public void deleteSymptom(ActionEvent event) {
		if(!selectedSymptom.isEmpty()) {
			selectedSymptom.remove(selectedSymptom.size() - 1);
			listView.getItems().remove(listView.getItems().size() - 1);
		}
	}
	
	
	
	// -------- Common Methods ----------
	public void options(MouseEvent event) {
		if (isOpen) {
			MyMove.startMove(optionPane, 0, 0, 250, 0);
			MyRotate.start(optionBtn, 0, 500, 0);
			isOpen = false;
		} else {
			MyMove.startMove(optionPane, 0, 160, 250, 0);
			MyRotate.start(optionBtn, 180, 500, 0);
			isOpen = true;
		}
	}

	public void diseasesInfo(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/DiseasesInfoScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void home(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/MainScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void aboutUs(ActionEvent event) throws IOException {
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/AboutUsScene.fxml"));
		Parent root = loader.load();
		Scene scene = new Scene(root);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(scene);
		stage.show();
	}

	public void exit(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		stage.close();
	}

	
	

	private String convertListToString() {
		String symptoms = "[";
		if (!selectedSymptom.isEmpty()) {
			for (int i = 0; i < selectedSymptom.size() - 1; i++) {
				symptoms += selectedSymptom.get(i) + ",";
			}
			symptoms += selectedSymptom.get(selectedSymptom.size() - 1);
		}
		symptoms += "]";
		return symptoms;
	}

	private LinkedList<String> splitSymptoms(String str) {
		LinkedList<String> splitResult = new LinkedList<>();
		String[] strTempArr = {};
		char[] charArray = str.toCharArray();
		String strTemp = "";
		
		// Delete left and right square brackets.
		for (int i = 1; i < charArray.length - 1; i++) {
			strTemp += charArray[i];
		}
		strTempArr = strTemp.split(",");

		// Delete spaces from first and last each element.
		for(int i = 0; i < strTempArr.length; i++) {
			splitResult.add(strTempArr[i].trim());
		}
		
		return deleteRepeated(splitResult);
	}
	
	private LinkedList<String> splitDrugs(String str) {
		LinkedList<String> splitResult = new LinkedList<>();
		String[] strTempArr = {};
		char[] charArray = str.toCharArray();
		String strTemp = "";
		
		// Delete left and right square brackets.
		for (int i = 1; i < charArray.length - 1; i++) {
			strTemp += charArray[i];
		}
		strTempArr = strTemp.split(",");

		// Delete spaces from first and last each element.
		for(int i = 0; i < strTempArr.length; i++) {
			splitResult.add(getString(strTempArr[i].trim()));
		}
		
		return deleteRepeated(splitResult);
	}

	private LinkedList<String> deleteRepeated(LinkedList<String>  strArr) {
		LinkedList<String> deleteRepeated = new LinkedList<>();
		
		// Delete the repeated elements.
		for (int i = 0; i < strArr.size(); i++) {
			if(!isMember(deleteRepeated, strArr.get(i))) {
				deleteRepeated.add(strArr.get(i));
			}
		}
		
		return deleteRepeated;
	}
	
	private boolean isMember(LinkedList<String> strArr, String str) {
		// Check if the element is a member in the array.
		for (int i = 0; i < strArr.size(); i++) {
			if (strArr.get(i).equalsIgnoreCase(str)) {
				return true;
			}
		}
		return false;
	}
	
	private String getString(String str) {
		String getString = "";
		char[] temp = str.toCharArray();
		
		
		for(int i = 1; i < str.length() -1; i++) {
			getString += temp[i];
		}
		
		return getString;
	}
	
	
	
	
}
